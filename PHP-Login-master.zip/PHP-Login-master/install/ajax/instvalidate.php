<?php
echo file_exists($_POST['dirpath']);