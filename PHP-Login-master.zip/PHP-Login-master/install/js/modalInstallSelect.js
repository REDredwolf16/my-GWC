$(document).ready(function(){
   $('#instTypeModal').modal('show');
});
