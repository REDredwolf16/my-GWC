<?php

// Define the buttons in the menu bar
$barmenu = array(
    "Homepage" => "index.php",
    "Private Page" => "page_2.php",
    "Public Page" => "page_3.php",
    "Other Pages" => array(
        "PHP-Login Github" => "https://github.com/therecluse26/PHP-Login",
        "Site Root" => "/"),
    "Admin Page" => "page_4.php",
);
