# learningAPIs
2018 GWC AT&amp;T SIP learning APIs starter code.
